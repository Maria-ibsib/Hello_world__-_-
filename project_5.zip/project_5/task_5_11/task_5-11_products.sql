-- 1. Вывести все товары из категории «Электроника»
SELECT *
FROM products
WHERE category = 'Электроника';

-- 2. Вывести товары из категории «Одежда», у которых в названии есть слово «женские»
SELECT *
FROM products
WHERE category = 'Одежда' AND name LIKE '%женские%';

-- 3. Вывести товары категории «Продукты» или «Книги»
SELECT *
FROM products
WHERE category = 'Продукты' OR category = 'Книги';

-- 4. Вывести товары, не относящиеся к категории «Бытовая техника»
SELECT *
FROM products
WHERE NOT category = 'Бытовая техника';

-- 5. Вывести товары категорий «Электроника», «Одежда», «Книги»
SELECT *
FROM products
WHERE category IN ('Электроника', 'Одежда', 'Книги');

-- 6. Вывести товары, которые:
--    относятся к «Электроника» И название содержит «Samsung»
--    ИЛИ относятся к «Бытовая техника»
SELECT *
FROM products
WHERE (category = 'Электроника' AND name LIKE '%Samsung%')
   OR category = 'Бытовая техника';

-- 7. Вывести товары, которые:
--    относятся к «Электроника», «Одежда», «Бытовая техника»
--    И id от 1 до 15
--    И название НЕ содержит «Samsung»
--    ИЛИ относятся к «Книги»
SELECT *
FROM products
WHERE (category IN ('Электроника', 'Одежда', 'Бытовая техника')
       AND id BETWEEN 1 AND 15
       AND name NOT LIKE '%Samsung%')
   OR category = 'Книги';
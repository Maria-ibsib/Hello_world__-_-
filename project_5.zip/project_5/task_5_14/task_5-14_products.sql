-- Задание 1: Вывести список товаров из таблицы products, переименовав столбцы
SELECT 
    name AS "Название товара",
    category AS "Категория"
FROM products;
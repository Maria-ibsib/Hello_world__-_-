-- 1. Вывести все товары
SELECT *
FROM products;

-- 2. Вывести только название и категорию
SELECT name, category
FROM products;

-- 3. Вывести все уникальные категории
SELECT DISTINCT category
FROM products;

-- 4. Вывести товары по названию (А-Я)
SELECT *
FROM products
ORDER BY name ASC;

-- 5. Вывести товары по названию (Я-А)
SELECT *
FROM products
ORDER BY name DESC;

-- 6. Вывести первые 10 товаров
SELECT *
FROM products
LIMIT 10;

-- 7. Вывести 10 товаров с 11-й записи
SELECT *
FROM products
LIMIT 10 OFFSET 10;

-- 8. Вывести 5 случайных товаров
SELECT *
FROM products
ORDER BY RANDOM()
LIMIT 5;

-- 9. Вывести все категории (без DISTINCT) по алфавиту
SELECT category
FROM products
ORDER BY category ASC;

-- 10. Вывести товары по категории и названию
SELECT *
FROM products
ORDER BY category ASC, name ASC;
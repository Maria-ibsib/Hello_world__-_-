-- Вывести список уникальных поставщиков
SELECT DISTINCT name
FROM suppliers
ORDER BY name;
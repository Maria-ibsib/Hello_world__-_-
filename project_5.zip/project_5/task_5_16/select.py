import psycopg2

try:
    # Устанавливаем соединение
    connection = psycopg2.connect(
        host="localhost",          # База в контейнере, но доступна через localhost
        port="5435",               # Порт из секции ports
        user="postgres",           # POSTGRES_USER
        password="student",        # POSTGRES_PASSWORD
        database="student_task"          # POSTGRES_DB
    )
    cursor = connection.cursor()

    # 1. Выполняем запрос с JOIN для таблиц products и prices
    cursor.execute("""
        SELECT 
            p.name AS "название товара",
            pr.price AS "цена"
        FROM products AS p
        JOIN prices AS pr ON p.id = pr.product_id;
    """)

    # 2. Извлекаем все строки
    products_with_prices = cursor.fetchall()

    for product in products_with_prices:
        print(f"Товар: {product[0]}, Цена: {product[1]}")

    # Не забываем закрыть курсор
    cursor.close()
    connection.close()  # Рекомендуется также закрывать соединение

except Exception as error:
    print(f"Ошибка при подключении: {error}")
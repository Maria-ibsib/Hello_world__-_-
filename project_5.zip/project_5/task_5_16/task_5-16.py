import psycopg2

try:
    # Устанавливаем соединение
    connection = psycopg2.connect(
        host="localhost",
        port="5432",
        user="postgres",
        password="example",
        database="testdb"
    )

    cursor = connection.cursor()

    # Выполняем SQL-запрос (например, получаем версию PostgreSQL)
    cursor.execute("SELECT version();")
    version = cursor.fetchone()
    print(f"Версия PostgreSQL: {version[0]}")

    # Закрываем курсор и соединение
    cursor.close()
    connection.close()
    print("✅ Подключение успешно и закрыто!")

except Exception as error:
    print(f"❌ Ошибка при подключении: {error}")
import psycopg2

connection = None
cursor = None

try:
    # Устанавливаем соединение
    connection = psycopg2.connect(
        host="localhost",
        port="5435",
        user="postgres",
        password="student",
        database="student_task"
    )
    cursor = connection.cursor()

    # Выполняем SELECT с JOIN
    cursor.execute("""
        SELECT 
            p.name AS "название товара",
            pr.price AS "цена"
        FROM products AS p
        JOIN prices AS pr ON p.id = pr.product_id;
    """)

    # Получаем результаты
    results = cursor.fetchall()

    # Выводим результаты
    if results:
        print("Список товаров с ценами:")
        print("-" * 30)
        for row in results:
            print(f"Товар: {row[0]}, Цена: {row[1]}")
    else:
        print("Данные не найдены. Возможно, таблицы пустые.")

    connection.commit()

except Exception as error:
    if connection:
        connection.rollback()
    print(f"Ошибка: {error}")

finally:
    if cursor is not None:
        cursor.close()
    if connection is not None:
        connection.close()
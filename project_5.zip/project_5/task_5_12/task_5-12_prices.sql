-- 1. Вывести количество (COUNT) записей в таблице prices для каждого товара (product_id)
SELECT product_id, COUNT(*) AS price_count
FROM prices
GROUP BY product_id
ORDER BY product_id;

-- 2. Вывести среднюю цену товаров (AVG(price)) для каждого product_id из таблицы prices
SELECT product_id, AVG(price) AS average_price
FROM prices
GROUP BY product_id
ORDER BY product_id;

-- 3. Вывести минимальную (MIN) цену для каждого товара (product_id) из таблицы prices
SELECT product_id, MIN(price) AS min_price
FROM prices
GROUP BY product_id
ORDER BY product_id;

-- 4. Вывести максимальную (MAX) цену для каждого товара (product_id) из таблицы prices
SELECT product_id, MAX(price) AS max_price
FROM prices
GROUP BY product_id
ORDER BY product_id;
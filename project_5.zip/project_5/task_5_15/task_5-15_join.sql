-- Задание: Вывести список цен товаров, используя алиасы таблиц
-- products → p, prices → pr
-- Вывести: название товара, цену

SELECT 
    p.name AS "название товара",
    pr.price AS "цена"
FROM products AS p
JOIN prices AS pr ON p.id = pr.product_id;
-- Проверка: какие товары будут обновлены?
SELECT *
FROM prices
WHERE price < 1000;
-- Задание 1: Увеличить цену на 10% для всех товаров, у которых текущая цена меньше 1000
UPDATE prices
SET price = price * 1.10
WHERE price < 1000;
-- Проверка: посмотреть обновленные записи
SELECT *
FROM prices
WHERE price < 1100 AND price >= 1000;
-- или просто посмотрите, как изменились цены
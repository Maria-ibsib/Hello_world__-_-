-- Проверка: какие товары будут обновлены?
SELECT *
FROM prices
WHERE product_id <= 5 AND price < 10000;
-- Задание 2: Увеличить цену на 5% для товаров, где product_id ≤ 5 и цена меньше 10000
UPDATE prices
SET price = price * 1.05
WHERE product_id <= 5 AND price < 10000;
-- Проверка: посмотреть обновленные записи
SELECT *
FROM prices
WHERE product_id <= 5;